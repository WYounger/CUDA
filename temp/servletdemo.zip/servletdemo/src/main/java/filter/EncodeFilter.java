package filter;

import pojo.MyHttpRequest;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @author Young
 */
public class EncodeFilter implements Filter {
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest)servletRequest;
        HttpServletResponse res = (HttpServletResponse)servletResponse;

        //对以post方式的请求的乱码解决方式
        req.setCharacterEncoding("UTF-8");
        //对response乱码的解决方式
        res.setCharacterEncoding("UTF-8");
        res.setContentType("text/html;charset=UTF-8");
        //对以get方式的请求乱码解决方式
        MyHttpRequest request_  = new MyHttpRequest(req);
        //将增强后的request传递下去
        filterChain.doFilter(request_,res);
    }

    @Override
    public void destroy() {

    }
}
