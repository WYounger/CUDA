package controller;

import annotation.MyRequestMapping;
import pojo.User;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Young
 *
 * 一个控制器
 */
public class TestController {

    @MyRequestMapping(value="/test.do")
    public Map<String,Object> test(User user){
        Map<String,Object> result = new HashMap<>(10);
        result.put("name",user.getName());
        result.put("age",user.getAge());
        result.put("view","forward:/WEB-INF/showInfo.jsp");
        return result;
    }
}
