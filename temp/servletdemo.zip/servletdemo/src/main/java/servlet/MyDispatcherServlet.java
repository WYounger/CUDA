package servlet;

import utils.ResolveXML;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.util.Map;

/**
 * @author Young
 * 请求转发器
 */
public class MyDispatcherServlet extends HttpServlet {
    /**
     * 1.读取配置文件(仅有controller的全限定类名）,存放到list中
     * 2.依据list中类的权限定名，获取在其内的方法上的MyRequestMapping,
     *   将<url,handlerMethod>保存起来
     * 3.HandlerMethod同一返回
     *
     */
    /**
     * <request,handlerMethod>
     */
    private static Map<String, Method> requestMap;
    private String REDIRECT = "redirect";
    static {
        //解析config.xml
        requestMap = ResolveXML.getRequestMap();
    }
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doPost(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String[] strings = req.getRequestURI().split("/");
        Method method= requestMap.get("/"+strings[strings.length-1]);
        Map<String, String[]> parameterMap = req.getParameterMap();
        Parameter[] parameters = method.getParameters();
        Object object = null;
        for(Parameter parameter:parameters){
            if(parameter.getType().isPrimitive()){
                //这里要判断原始类型，然后将请求参数(String)转换为对应的类型
                //...
            }else{
                //然后要判断是否是原始类型的包装类型还是自定义对象
                //当前假设是是自定义对象
                Class clazz = parameter.getType();
                try {
                    object = clazz.getConstructor(null).newInstance(null);
                    Field[] declaredFields = clazz.getDeclaredFields();
                    for(Field field:declaredFields){
                        field.setAccessible(true);
                        if(field.getType().equals(int.class)){
                            field.set(object,Integer.parseInt(parameterMap.get(field.getName())[0]));
                        }else if(field.getType().equals(String.class)){
                            field.set(object,parameterMap.get(field.getName())[0]);
                        }

                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        try {
            Map<String, Object> result = (Map<String, Object>) method.invoke(method.getDeclaringClass().getConstructor(null).newInstance(null),
                    object);
            String view = null;
            for(Map.Entry<String,Object> entry:result.entrySet()){
                if(!entry.getKey().equalsIgnoreCase("view")){
                    req.setAttribute(entry.getKey(),entry.getValue());
                }else{
                    view = (String) entry.getValue();
                }
            }
            String[] views = view.split(":");

            if(REDIRECT.equalsIgnoreCase(views[0])){
                resp.sendRedirect(views[1]);
            }else{
                req.getRequestDispatcher(views[1]).forward(req,resp);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
