package pojo;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import java.io.UnsupportedEncodingException;

/**
 * @author Young
 */
public class MyHttpRequest extends HttpServletRequestWrapper {
    final  String GET = "get";
    private HttpServletRequest request;
    public MyHttpRequest(HttpServletRequest request) {
        super(request);
        this.request  = request;
    }

    @Override
    public String getParameter(String name) {
        String value = this.request.getParameter(name);
        if(value == null){
            return null;
        }
        //如果不是get请求,直接返回值
        if(!this.request.getMethod().equalsIgnoreCase(GET)){
            return value;
        }
        //处理get请求
        try {
            value = new String(value.getBytes("ISO8859-1"),this.request.getCharacterEncoding());
            return value;
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return null;
    }
}
