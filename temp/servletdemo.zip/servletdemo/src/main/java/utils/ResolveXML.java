package utils;

import annotation.MyRequestMapping;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import java.io.File;
import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Young
 */
public class ResolveXML {
    private static Map<String,Method> map  = new HashMap<>(10);

    public static Map<String, Method>  getRequestMap(){
        //解析xml
        String xmlPath = ResolveXML.class.getResource("/config.xml").getPath();
        try {
            Element rootElement = new SAXReader().read(new File(xmlPath)).getRootElement();
            List<Element> childElements = rootElement.elements();
            for (Element e : childElements) {
                String  classFullyQualifiedName = e.elementText("class");
                System.out.println("classFullyQualifiedName:"+classFullyQualifiedName);
                resolveClass(classFullyQualifiedName);
            }

        } catch (DocumentException e) {
            e.printStackTrace();
        }
        return map;
    }

    private static void resolveClass(String classFullyQualifiedName){
        try {
            Class clazz = Class.forName(classFullyQualifiedName);
            Method[] methods  = clazz.getDeclaredMethods();
            for(Method method:methods){
                System.out.println("methodName: "+method.getName());
                Annotation[] annotations = method.getAnnotations();
                for(Annotation annotation:annotations){
                    if(annotation.annotationType().equals(MyRequestMapping.class)){
                        String url = ((MyRequestMapping)annotation).value();
                        map.put(url,method);
                        return;
                    }
                }
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        getRequestMap();
    }
}
