package annotation;

import java.lang.annotation.*;

/**
 * @author Young
 * 自定义一个注解类
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
@Documented
public @interface MyRequestMapping {
    String value() default "";
}
