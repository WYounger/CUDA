###### bool查询

一个或多个查询子句的组合。包含四种子句

![](img/bool.jpg)

- 子查询可以任意出现
- 可以并列和嵌套多个查询
- 如果没有must条件，should中必须至少满需一项。反之，如果存在并且满足must条件，可以不满足should任一一项

```json
GET book/_search
{
  "query": {
    "bool": {
     "must": [
       {
         "range": {
           "price": {
             "gte": 99,
             "lte": 100
           }
         }
       }
     ], 
      "should": [
        {"term": {
          "subject": {
            "value": "java"
          }
        }},
        {
          "term": {
            "subject": {
              "value": "c++"
            }
          }
        }
      ]
    }
  }
}
```

