###### 分页

```json
GET stu/_search
{
  "query": {
    "match_all": {}
  },
  "from": 2,
  "size": 3
}
```

- from默认从0开始
- 获取靠后的数据成本较高

###### 排序

```json
GET stu/_search
{
  "query": {
    "match_all": {}
  },
  "from": 2,
  "size": 3,
  "sort": [
    {
      "age": {
        "order": "desc"
      }
    }
  ]
}
```

- 最好在数字型和日期字段上排序

###### _source filtering

返回指定的字段

```json
GET stu/_search
{
  "_source": ["name","age"]
}
```

###### 脚本字段

```json
GET stu/_search
{
  "script_fields": {
    "name_age": {
      "script": {
        "lang": "painless",
        "source": "doc['name.keyword']+params.seperator+doc['age']",
        "params": {
          "seperator":"_"
        }
      }
    }
  }
}
```

###### 基本查询用法

```json
# term精确匹配
GET book/_search
{
  "query": {
    "term": { # 查询price=100的doc
      "price": {
        "value": 100
      }
    }
  }
}

# 使用constant_sroce filter，不计算分
GET book/_search
{
  "query": {
    "constant_score": {
      "filter": {
        "term": {
          "price": 100
        }
      }
    }
  }
}

# range查询
GET book/_search
{
  "query": {
    "range": { # 80 <= price <= 100
      "price": {
        "gte": 80,
        "lte": 100
      }
    }
  }
}

# 字段非空查询
GET book/_search
{
  "query": {
    "exists": { # title字段存在，并且不为null
      "field": "title"
    }
  }
}
```

