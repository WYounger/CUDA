###### completion suggester

当用户进行搜索时，输入字符串前缀，系统返回匹配前缀的推荐词条。

ES使用FST来实现快速搜索。

FST只能用于前缀查找

###### 步骤

1. 定义Mapping，使用"completion" type
2. 索引数据
3. 使用suggest查询数据

```json
PUT articles
{
  "mappings": {
    "properties": {
      "title":{  # 定义类型为completion
        "type": "completion"
      }
    }
  }
}

GET articles/_search
{
  "size": 0,
  "suggest": {
    "title_suggest": {
      "prefix":"jav",
      "completion":{
        "field":"title"
      }
    }
  }
}
```

