##### 创建文档的几种方式

###### create

- 自动生成文档id

  ```json
  POST stu/_doc
  {
    "name":"testCreate1"
  }
  ```

- 指定文档id

  如果当文档id已经存在，那么此次创建失败

  ```json
  PUT stu/_create/10
  {
    "name":"testCreate10"
  }
  ```

###### index

index和create的区别:  如果文档已经不存在，就索引新的文档。否则现有的文档会被删除，新的文档的被索引，版本信息加一

```json
PUT stu/_doc/11
{
  "name":"testIndex11"
}
# 每次执行，version+1
```

###### update

- update方法不会删除原来的文档，而是实现真正的数据更新
- post方法playload放在doc中

```json
# 对id=12的文档修改了name,同时添加了一个age字段
POST stu/_update/12
{
  "doc": {
    "name": "newTestUpdate12",
    "age":12
  }
}
```

##### 获取详情

```json
GET stu/_doc/12
```

##### Bulk API

- 支持在一次API调用中，对不同索引进行操作
- 支持四种类型操作
  - Index
  - Create
  - Update
  - Delete
- 可以在URI中指定Index,也可以在playload中进行
- 操作中单条失败，并不会影响其他操作
- 返回结果包括每一条操作执行的结果

```json
# playload中指定index
POST _bulk
{"index":{"_index":"test","_id":1}}
{"fild1": "value1"}
{"delete":{"_index":"test","_id":2}}
{"create":{"_index":"test","_id":3}}
{"fild1": "value3"}
{"update":{"_index":"test","_id":3}}
{"doc":{"fild2": "value2"}}

# uri中指定index
POST articles/_bulk
{"index":{}}
{"title":"title1"}
{"index":{}}
{"title":"title2"}
{"index":{}}
{"title":"title3"}
```

批量读取

```json
GET /_mget
{
  "docs":[
    {
      "_index":"stu",
      "_id":1
    },
    {
      "_index":"articles",
      "_id":1
    }
  ]
}
```





