###### 什么是Mapping

- 定义索引中的字段名称

- 定义字段的数据类型，比如字符串、数字、布尔...
- 字段、倒排索引的相关配置
- Mapping会把JSON文档映射成Lucenne所需要的扁平格式
- 一个Mapping属于一个索引的Type
  - 每个文档都属于一个Type
  - 一个Type有一个Mapping定义

字段的数据类型

- 简单类型

  - Text/Keyword
  - Date
  - Integer/Floating
  - Boolean
  - IPv4&IPv6

- 复杂类型

  - 对象
  - 嵌套

- 特殊类型

  geo_point / geo_shape / percolator

###### 什么是Dynamic Mapping

- 在写入文档时候，如果索引不存在，就会自动创建索引
- Danamic Mapping的机制，使得我们无需手动定义Mappings.ES会自动根据文档信息推算出字段类型
- 但是，推断类型不一定每次都对

![](img/类型推断.jpg)

###### 更改Mapping的字段类型

- 两种情况
  - 新增字段
    - Dynamic为true时，一旦有新增的字段写入文档，Mapping也同时会被更新
    - Dynamic为false时，Mapping不会被更新，新增字段的数据无法被索引，但是信息会出现在_source中
    - Dynamic为strict时，文档写入失败
  - 对已有字段
    - 一旦有数据写入，就不再支持修改字段定义
      - Lucene实现的倒排索引，一旦生成后，就不允许被修改
    - 如果希望改变字段类型，必须Reindex API,重建索引
- 原因
  - 如果修改了字段的数据类型，会导致已被索引的数据无法被索引
  - 但是如果新增字段，就不会影响原来的字段索引

###### 显示定义Mapping

```json
PUT book
{
  "mappings": {
    "properties": {
      "title":{
        "type": "text",
        "index": true
      },
      "publish_date":{
        "type": "date",
        "format": "yyyy-MM-dd HH:mm:ss"
      }
    }
  }
}
```

```json
# GET /book/_mapping
{
  "book" : {
    "mappings" : {
      "properties" : {
        "publish_date" : {
          "type" : "date",
          "format" : "yyyy-MM-dd HH:mm:ss"
        },
        "title" : {
          "type" : "text"
        }
      }
    }
  }
}

PUT book/_doc/1
{
  "title":"effective java",
  "publish_date":"2019-01-01 01:02:02"
}

# GET /book/_doc/1
{
  "_index" : "book",
  "_type" : "_doc",
  "_id" : "1",
  "_version" : 1,
  "_seq_no" : 0,
  "_primary_term" : 1,
  "found" : true,
  "_source" : {
    "title" : "effective java",
    "publish_date" : "2019-01-01 01:02:02"
  }
}

```

可选参数

index: 该字段是否被索引，默认是true

format: 日期格式化，默认带时区

###### 精确值和全文本

- Exact Value: 包括数字、日期、具体的一个字符串
  - ES中的keyword
  - index时，不会做分词处理
- Full text: 非结构化的数据
  - ES中的text
  - index时，会做分词处理

###### 分词

- 分词处理流程

  Character Filters  =>  Tokenizer  => Token Filters

- Character Filters

  - 在Tokenizer之前对文本进行处理，例如增加、删除、替换字符。可以配置多个
  - 自带
    - HTML strip  -- 去除html标签
    - Mapping -- 字符串替换
    - Pattern replace -- 正则匹配

- Tokenizer

  - 将原始的文本，按照一定的规则，切分为词

  - 自带

    whitespace/standard/pattern/uax_	url_email/path hierachy

  - Java插件自定义

- Token Filters

  - 将Tokenizer输出的term，进行增加、删除、修改

  - 自带

    LowerCase/stop/synonym(近义词)

```json
# html标签替换
POST _analyze
{
  "tokenizer": "keyword",
  "char_filter": ["html_strip"],
  "text": "<div>hello world</div>"
}
# mapping替换
POST _analyze
{
  "tokenizer": "standard",
  "char_filter": [{
    "type":"mapping",
    "mappings":["hello => hi","-^-^- => smile"]
  }],
  "text": "hello -^-^-"
}
# 正则表达式替换
POST _analyze
{
  "tokenizer": "standard",
  "char_filter": [
    {
      "type":"pattern_replace",
      "pattern":"http://(.*)",
      "replacement":"$1"
    }],
    "text": "http://younger.com"
}

# tokenizer
POST _analyze
{
  "tokenizer": "path_hierarchy",
  "text": "/a/b/c"
}
 
```

###### index template

![](img/index_template.jpg)

![](img/index_template_exaple.jpg)

###### dynamic template

![](img/dynamic_template.jpg)

![](img/dynamic_template_example.jpg)